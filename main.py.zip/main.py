from tkinter import *
from tkinter import ttk
import random,os
from tkinter import messagebox
import tempfile




class Bill_App:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1470x800+0+0")  
        self.root.title("BILLING SOFTWARE")

        #========================    VARIABLES   ===========================
        self.c_name=StringVar()
        self.c_phone=StringVar()
        self.no_bill=StringVar()
        x=random.randint(1000,9999)
        self.no_bill.set(x)
        self.c_email=StringVar()
        self.search_bill=StringVar()
        self.product=StringVar()
        self.prices=IntVar()
        self.qty=IntVar()
        self.sub_total=StringVar()
        self.tax_input=StringVar()
        self.total=StringVar()





        #product category
        self.category=["Select Option","Mobiles","Clothing"]

        #subcategory MOBILES
        self.subcatmobiles=["IPHONE","SAMSUNG","GOOGLE"]
        self.iphone=["IPHONE 11","IPHONE 14 PRO"]
        self.iphone11_prize=55000
        self.iphone14pro_prize=120000

        self.samsung=["S22 ULTRA","S22"]
        self.s22ultra_prize=120000
        self.s22_prize=54000

        self.google=["PIXEL 6a","PIXEL 7 PRO"]
        self.pixel6a_prize=40000
        self.pixel7pro=90000        

        #sucategoary CLOTHING

        self.subcatcloth=["SHIRT","PANT"]
        self.shirt=["ARMANI EXCHANGE","GUCCI"]
        self.armani_prize=6000
        self.gucci_prize=20000

        self.pant=["VOI JEANS","RARERABBIT"]
        self.voi_prize=3000
        self.rare_prize=4000


        
        
        #for Tile
        lbl_title=Label(self.root,text="BILLING SOFTWARE",font = ("times new roman",35,"bold"),bg = "white",fg = "black" )
        lbl_title.place(x = 0,y = 0,width = 1470, height = 50)

        #for main Frame
        main_frame=Frame(self.root,bd = 5,relief = GROOVE,bg = "white")
        main_frame.place(x = 0,y = 60,width = 1470,height = 850)

        #for coustamer details frame 
        cust_frame=LabelFrame(main_frame,text="Customer Details",font = ("times new roman",25,"bold"),bg = "white",fg = "red")
        cust_frame.place(x=10,y=10,width=470,height = 220)

        lbl_mob=Label(cust_frame,text = "Mobile number:",font = ("times new roman",20,"bold"),bg = "white",fg = "black")
        lbl_mob.grid(row=0,column=0,stick = W ,padx=5,pady=10)

        self.entry_mob=ttk.Entry(cust_frame,font = ("times new roman",18,"bold"),width = 27,textvariable=self.c_phone)
        self.entry_mob.grid(row=0,column=1)

        self.lblcustname=Label(cust_frame,text=("Customer Name:"),font=("arial",20,"bold"),bg="white",fg="black",bd=4)
        self.lblcustname.grid(row=1,column = 0,sticky=W,padx=5,pady=10)

        self.txtcustname=ttk.Entry(cust_frame,font=("arial",18,"bold"),width = 22,textvariable=self.c_name)
        self.txtcustname.grid(row=1,column=1)

        self.lblEmail=Label(cust_frame,font=("arial",20,"bold"),bg="white",fg="black",bd=4,text="Email:")
        self.lblEmail.grid(row=2,column=0,sticky=W,padx=5,pady=10)

        self.txtEmail=ttk.Entry(cust_frame,font=("arial",18,"bold"),width = 22,textvariable=self.c_email)
        self.txtEmail.grid(row=2,column=1)

        #for product details frame 
        product_frame=LabelFrame(main_frame,text="Product Details",font = ("times new roman",25,"bold"),bg = "white",fg = "red")
        product_frame.place(x=10,y=240,width=470,height = 320)

        #select catogary
        self.lblcategory=Label(product_frame,font=("arial",20,"bold"),bg="white",fg="black",bd=4,text="Select Category:")
        self.lblcategory.grid(row=0,column=0,sticky=W,padx=5,pady=10)

        #combobox
        self.combo_catogery=ttk.Combobox(product_frame,font=("arial",20,"bold"),width = 20,state= "readonly",values=self.category)
        self.combo_catogery.current(0)
        self.combo_catogery.grid(row=0,column=1,sticky=W,padx=5,pady=10)
        self.combo_catogery.bind("<<ComboboxSelected>>",self.categories)

        #subcategoary
        self.lblsubcategory=Label(product_frame,font=("arial",20,"bold"),bg="white",fg="black",bd=4,text="Sub Category:")
        self.lblsubcategory.grid(row=1,column=0,sticky=W,padx=5,pady=10)

        #combobox
        self.combo_subcatogery=ttk.Combobox(product_frame,font=("arial",20,"bold"),width = 20,state= "readonly",values=[""]) 
        self.combo_subcatogery.grid(row=1,column=1,sticky=W,padx=5,pady=10)
        self.combo_subcatogery.bind("<<ComboboxSelected>>",self.product_add)

        #product
        self.lblproduct=Label(product_frame,font=("arial",20,"bold"),bg="white",fg="black",bd=4,text="Product:")
        self.lblproduct.grid(row=2,column=0,sticky=W,padx=5,pady=10)

        #combobox
        self.combo_product=ttk.Combobox(product_frame,font=("arial",20,"bold"),width = 20,state= "readonly",textvariable=self.product)
        self.combo_product.grid(row=2,column=1,sticky=W,padx=5,pady=10)
        self.combo_product.bind("<<ComboboxSelected>>",self.price)

        #price
        self.lblprize=Label(product_frame,font=("arial",20,"bold"),bg="white",fg="black",bd=4,text="Price:")
        self.lblprize.grid(row=3,column=0,sticky=W,padx=5,pady=10)

         #combobox
        self.combo_prize=ttk.Combobox(product_frame,font=("arial",20,"bold"),width = 20,state= "readonly",textvariable=self.prices)
        self.combo_prize.grid(row=3,column=1,sticky=W,padx=5,pady=10)

        #Qty
        self.lblqty=Label(product_frame,font=("arial",20,"bold"),bg="white",fg="black",bd=4,text="Qty:")
        self.lblqty.grid(row=4,column=0,sticky=W,padx=5,pady=10)

        #combobox
        self.Entry_qty=ttk.Entry(product_frame,font=("arial",20,"bold"),width = 21,textvariable=self.qty)
        self.Entry_qty.grid(row=4,column=1,sticky=W,padx=5,pady=10)

        #search

        search_frame=Frame(main_frame,bd=10,bg="white")
        search_frame.place(x=490,y=15,width=600,height=60)

        self.bill_no=Label(search_frame,font=("arial",25,"bold"),bg="red",fg="black",bd=1,text="Bill NO:",width=10,height=1)
        self.bill_no.grid(row=0,column=0,sticky=W,padx=1)       

        self.entry_search=ttk.Entry(search_frame,font=("arial",20,"bold"),width = 21,textvariable=self.search_bill)
        self.entry_search.grid(row=0,column=1,sticky=W,padx=5)

        self.btnsearch=Button(search_frame,text="search",font=("arial",20,"bold"),bg="white",fg="red",width=10,cursor="hand2",command=self.find_bill)
        self.btnsearch.grid(row=0,column=2)


        #right frame bill area
        billframe=LabelFrame((main_frame),text="BILL",font = ("times new roman",25,"bold"),bg = "white",fg = "red")
        billframe.place(x = 500,y = 60,width=580,height=500)

        #scroll 
        scroll_y=Scrollbar(billframe,orient=VERTICAL)
        self.textarea=Text(billframe,yscrollcommand=scroll_y.set,bg="white",fg="blue",font = ("times new roman",20,"bold"))
        scroll_y.pack(side=RIGHT,fill=Y)
        scroll_y.config(command=self.textarea.yview)
        self.textarea.pack(fill=BOTH,expand=1)
    
        #bottom counter lable frame
        bottom_frame=LabelFrame(main_frame,text="Bill Counter",font = ("times new roman",25,"bold"),bg = "white",fg = "red")
        bottom_frame.place(x=10,y=560,width=1470,height = 170)

        #subtotal
        self.subtotal=Label(bottom_frame,font=("arial",20,"bold"),bg="white",fg="black",bd=4,text="Sub Total:")
        self.subtotal.grid(row=0,column=0,sticky=W,padx=5,pady=5)

        self.subtotal=ttk.Entry(bottom_frame,font=("arial",20,"bold"),width = 21,textvariable=self.sub_total)
        self.subtotal.grid(row=0,column=1,sticky=W,padx=5,pady=5)

        #TAX
        self.lbl_tax=Label(bottom_frame,font=("arial",20,"bold"),bg="white",fg="black",bd=4,text="TAX:")
        self.lbl_tax.grid(row=1,column=0,sticky=W,padx=5,pady=5)
       
        self.txt_tax=ttk.Entry(bottom_frame,font=("arial",20,"bold"),width = 21,textvariable=self.tax_input)
        self.txt_tax.grid(row=1,column=1,sticky=W,padx=5,pady=5)

        #Total Amount
        self.lbl_totalamount=Label(bottom_frame,font=("arial",20,"bold"),bg="white",fg="black",bd=4,text="Total Amount:")
        self.lbl_totalamount.grid(row=2,column=0,sticky=W,padx=5,pady=5)
       
        self.txt_totalamount=ttk.Entry(bottom_frame,font=("arial",20,"bold"),width = 21,textvariable=self.total)
        self.txt_totalamount.grid(row=2,column=1,sticky=W,padx=5,pady=5)

        #Button frame
        btn_frame=Frame(bottom_frame,bd=2,bg="white")
        btn_frame.place(x=450,y=5)

        self.btn_addtocart=Button(btn_frame,text="Add To Cart",font=("arial",30,"bold"),bg="white",fg="red",width=14,cursor="hand2",command=self.additem)
        self.btn_addtocart.grid(row=0,column=0,padx=3,pady=3)

        self.btn_generatebill=Button(btn_frame,text="Generate Bill",font=("arial",30,"bold"),bg="white",fg="red",width=14,cursor="hand2",command=self.gen_bill)
        self.btn_generatebill.grid(row=1,column=0,padx=3,pady=3)

        self.btn_save=Button(btn_frame,command=self.save_bill,text="Save Bill",font=("arial",30,"bold"),bg="white",fg="red",width=14,cursor="hand2")
        self.btn_save.grid(row=0,column=1,padx=3,pady=3)

        self.btn_print=Button(btn_frame,command=self.iprint,text="Print",font=("arial",30,"bold"),bg="white",fg="red",width=14,cursor="hand2")
        self.btn_print.grid(row=1,column=1,padx=3,pady=3)

        self.btn_clear=Button(btn_frame,text="Clear",font=("arial",30,"bold"),bg="white",fg="red",width=14,cursor="hand2",command=self.clear)
        self.btn_clear.grid(row=0,column=2,padx=3,pady=3)

        self.btn_exit=Button(btn_frame,text="Exit",font=("arial",30,"bold"),bg="white",fg="red",width=14,cursor="hand2",command=self.root.destroy)
        self.btn_exit.grid(row=1,column=2,padx=3,pady=3)

        self.welcome()
        self.l=[]
       # ********************************         FUNCTIONN DECLERATION             ************************************
       
    def welcome(self):
        self.textarea.delete(1.0,END)
        self.textarea.insert(END,"\t\t           WELCOME")
        self.textarea.insert(END,f"\n Bill NO:{self.no_bill.get()}")
        self.textarea.insert(END,f"\n Customer Name:{self.c_name.get()}")
        self.textarea.insert(END,f"\n Mobile Number:{self.c_phone.get()}")
        self.textarea.insert(END,f"\n Customer Email:{self.c_email.get()}")

        self.textarea.insert(END,"\n================================================")
        self.textarea.insert(END,"\n Products\t\t\tQty\t\tTotal Price")
        self.textarea.insert(END,"\n================================================\n")


    def additem(self):
        Tax=18
        self.n=self.prices.get()
        self.m=self.qty.get()*self.n
        self.l.append(self.m)
        if self.product.get()=="":
            messagebox.showerror("ERROR","Please enter the Product Name")
        else:
            self.textarea.insert(END,f"\n {self.product.get()}\t\t{self.qty.get()}\t\t{self.m}")
            self.sub_total.set(str("Rs.%.2f"%(sum(self.l))))
            self.tax_input.set(str("Rs.%.2f"%((((sum(self.l))-(self.prices.get()))*Tax)/100)))
            self.total.set(str("Rs.%.2f"%((sum(self.l))+((((sum(self.l))-(self.prices.get())))))))


    def gen_bill(self):
        if self.product.get()=="":
            messagebox.showerror("ERROR","Pleases Add To Cart any Product")
        else:
            text=self.textarea.get(10.0,(10.0+float(len(self.l))))
            self.welcome()
            self.textarea.insert(END,text)
            self.textarea.insert(END,"\n================================================")
            self.textarea.insert(END,f"\n Sub Amount:\t\t\t{self.sub_total.get()}")
            self.textarea.insert(END,f"\n Tax Amount:\t\t\t{self.tax_input.get()}")
            self.textarea.insert(END,f"\n Total Amount:\t\t\t{self.total.get()}")
            self.textarea.insert(END,"\n================================================")



    def save_bill(self):
        op=messagebox.askyesno("Save Bill","Do you want to save this Bill")
        if op > 0:
            self.bill_data=self.textarea.get(1.0,END)
            f1=open('bills/'+str(self.no_bill.get())+".txt","w")
            f1.write(self.bill_data)
            op=messagebox.showinfo("Saved",f"Bill No:{self.no_bill.get()}saved successfully")
            f1.close()


    def iprint(self):
        
        q=self.textarea.get(1.0,"end-1c")
        filename=tempfile.mktemp(".txt")
        open(filename,'w').write(q)
        os.startfile(filename,"Print")

    def find_bill(self):
        found="no"
        for i in os.listdir("bills/"):
            if i.split('.')[0]==self.search_bill.get():
                f1=open(f'bills/{i}','r')
                self.textarea.delete(1.0,END)
                for d in f1:
                    self.textarea.insert(END,d)
                f1.close()
                found="yes"
        if found=="no":
            messagebox.showerror("Error","Invalid Bill No.")

    def clear(self):
        self.textarea.delete(1.0,END)
        self.c_name.set('')
        self.c_phone.set('')
        self.c_email.set('')
        x = random.randint(1000,9999)
        self.no_bill.set(str(x))
        self.search_bill.set("")
        self.product.set("")
        self.prices.set(0)
        self.qty.set(0)
        self.l=[0]
        self.total.set("")
        self.sub_total.set("")
        self.tax_input.set("")
        self.welcome()






    def categories(self,e=""):
        if self.combo_catogery.get()=="Mobiles":
            self.combo_subcatogery.config(values=self.subcatmobiles)
            self.combo_subcatogery.current(0)

        if self.combo_catogery.get()=="Clothing":
            self.combo_subcatogery.config(values=self.subcatcloth)
            self.combo_subcatogery.current(0)


    def product_add(self,e=""):

        #PHONE
        if self.combo_subcatogery.get()=="IPHONE":
            self.combo_product.config(values=self.iphone)
            self.combo_product.current(0)

        if self.combo_subcatogery.get()=="SAMSUNG":
            self.combo_product.config(values=self.samsung)
            self.combo_product.current(0)

        if self.combo_subcatogery.get()=="GOOGLE":
            self.combo_product.config(values=self.google)
            self.combo_product.current(0)

        #CLOTHING
        if self.combo_subcatogery.get()=="SHIRT":
            self.combo_product.config(values=self.shirt)
            self.combo_product.current(0)
        
        if self.combo_subcatogery.get()=="PANT":
            self.combo_product.config(values=self.pant)
            self.combo_product.current(0)

    def price(self,e=""):

        #MOBILES
        if self.combo_product.get()=="IPHONE 11":
            self.combo_prize.config(values=self.iphone11_prize)
            self.combo_prize.current(0)
            self.qty.set(1)

        if self.combo_product.get()=="IPHONE 14 PRO":
            self.combo_prize.config(values=self.iphone14pro_prize)
            self.combo_prize.current(0)
            self.qty.set(1)

        if self.combo_product.get()=="S22 ULTRA":
            self.combo_prize.config(values=self.s22ultra_prize)
            self.combo_prize.current(0)
            self.qty.set(1)

        if self.combo_product.get()=="S22":
            self.combo_prize.config(values=self.s22_prize)
            self.combo_prize.current(0)
            self.qty.set(1)

        if self.combo_product.get()=="PIXEL 6a":
            self.combo_prize.config(values=self.pixel6a_prize)
            self.combo_prize.current(0)
            self.qty.set(1)

        if self.combo_product.get()=="PIXEL 7 PRO":
            self.combo_prize.config(values=self.pixel7pro)
            self.combo_prize.current(0)
            self.qty.set(1)

        #CLOTHING
        if self.combo_product.get()=="ARMANI EXCHANGE":
            self.combo_prize.config(values=self.armani_prize)
            self.combo_prize.current(0)
            self.qty.set(1)

        if self.combo_product.get()=="GUCCI":
            self.combo_prize.config(values=self.gucci_prize)
            self.combo_prize.current(0)
            self.qty.set(1)

        if self.combo_product.get()=="VOI JEANS":
            self.combo_prize.config(values=self.voi_prize)
            self.combo_prize.current(0)
            self.qty.set(1)

        if self.combo_product.get()=="RARERABBIT":
            self.combo_prize.config(values=self.rare_prize)
            self.combo_prize.current(0)
            self.qty.set(1)










        

       





if __name__ == "__main__":
    root=Tk()
    obj = Bill_App(root)
    root.mainloop()